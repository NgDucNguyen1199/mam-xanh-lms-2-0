// ===================================================================
// Official ADL SCORM 1.2 Runtime API Adapter (Mầm Xanh LMS 2.0)
// ===================================================================
(function(window) {
    var apiHandle = null;
    var initialized = false;
    var finished = false;
    var startTime = Date.now();

    function findAPI(win) {
        var attempts = 0;
        while ((win.API == null) && (win.parent != null) && (win.parent != win)) {
            attempts++;
            if (attempts > 10) return null;
            win = win.parent;
        }
        return win.API || null;
    }

    function getAPI() {
        if (apiHandle) return apiHandle;
        apiHandle = findAPI(window);
        if (!apiHandle && window.opener != null && typeof window.opener !== 'undefined') {
            apiHandle = findAPI(window.opener);
        }
        return apiHandle;
    }

    function formatScormTime(ms) {
        var totalSec = Math.max(1, Math.floor(ms / 1000));
        var h = String(Math.floor(totalSec / 3600)).padStart(4, '0');
        var m = String(Math.floor((totalSec % 3600) / 60)).padStart(2, '0');
        var s = String(totalSec % 60).padStart(2, '0');
        return h + ':' + m + ':' + s;
    }

    window.MXScorm12 = {
        init: function() {
            var api = getAPI();
            var badge = document.getElementById('scorm-conn-badge');
            if (api) {
                var res = api.LMSInitialize('');
                initialized = (res === 'true' || res === true);
                var curStatus = api.LMSGetValue('cmi.core.lesson_status');
                if (!curStatus || curStatus === 'not attempted') {
                    api.LMSSetValue('cmi.core.lesson_status', 'incomplete');
                    api.LMSSetValue('cmi.core.score.min', '0');
                    api.LMSSetValue('cmi.core.score.max', '100');
                    api.LMSCommit('');
                }
                if (badge) {
                    badge.textContent = '🟢 Đã kết nối Moodle SCORM 1.2 API (LMSInitialize OK)';
                    badge.style.background = '#D8F3DC';
                    badge.style.color = '#1B4332';
                }
            } else if (badge) {
                badge.textContent = '🟡 Chế độ Xem Độc lập (Standalone SCORM Preview)';
            }
            return initialized;
        },
        completeWithScore: function(rawScore) {
            var score = Math.max(0, Math.min(100, Math.round(rawScore)));
            var status = (score >= 70) ? 'completed' : 'incomplete';
            var api = getAPI();
            var logLines = [];

            if (api) {
                if (!initialized) {
                    api.LMSInitialize('');
                    initialized = true;
                }
                api.LMSSetValue('cmi.core.score.min', '0');
                api.LMSSetValue('cmi.core.score.max', '100');
                api.LMSSetValue('cmi.core.score.raw', String(score));
                api.LMSSetValue('cmi.core.lesson_status', status);
                api.LMSSetValue('cmi.core.session_time', formatScormTime(Date.now() - startTime));
                api.LMSCommit('');
                if (status === 'completed' && !finished) {
                    api.LMSFinish('');
                    finished = true;
                }
                logLines.push('LMSInitialize("") -> true');
                logLines.push('LMSSetValue("cmi.core.score.raw", ' + score + ') -> true');
                logLines.push('LMSSetValue("cmi.core.lesson_status", "' + status + '") -> true');
                logLines.push('LMSCommit("") & LMSFinish("") -> Đã đồng bộ về Moodle Gradebook!');
            } else {
                logLines.push('Mô phỏng SCORM 1.2: score.raw=' + score + ', lesson_status=' + status);
            }
            return { score: score, status: status, logs: logLines };
        }
    };
})(window);